import requests
import os
import time
from typing import Optional


class CaptchaAudioDecoder:
    def __init__(self, api_token: str = None):
    	
        self.API_TOKEN = api_token or "0e1ef6f52ce040fba237ae96d73b9872"
        
        self.API_BASE = "https://api.assemblyai.com/v2"
        self.UPLOAD_ENDPOINT = f"{self.API_BASE}/upload"
        self.TRANSCRIPT_ENDPOINT = f"{self.API_BASE}/transcript"
        
        self.http_client = requests.Session()
        self.http_client.headers.update({
            "authorization": self.API_TOKEN,
            "content-type": "application/json"
        })
        
    def decode_audio_captcha(self, audio_link: str, max_attempts: int = 5) -> str:
        for current_attempt in range(max_attempts):
        	
            try:
                
                self.remove_temp_files()
                local_audio = self._fetch_audio_file(audio_link)
                cloud_audio_url = self._send_to_transcription_service(local_audio)
                return self._get_transcription_result(cloud_audio_url)
                
            except Exception as error:
                if current_attempt == max_attempts - 1:
                	pass              
                time.sleep(2 ** current_attempt)
        
        pass
    
    def _fetch_audio_file(self, file_url: str, local_name: str = "captcha_audio.mp3") -> str:
        http_response = requests.get(file_url, timeout=30)
        http_response.raise_for_status()
        
        if os.path.exists(local_name):
            os.remove(local_name)
        
        with open(local_name, "wb") as audio_file:
            audio_file.write(http_response.content)
        
        return local_name
    
    def _send_to_transcription_service(self, file_path: str) -> str:
        with open(file_path, "rb") as audio_data:
            upload_response = requests.post(
                self.UPLOAD_ENDPOINT,
                headers={"authorization": self.API_TOKEN},
                files={"file": audio_data}
            )
            upload_response.raise_for_status()
            return upload_response.json()["upload_url"]
    
    def _get_transcription_result(self, audio_service_url: str, wait_limit: int = 60) -> str:
        start_transcription = self.http_client.post(
            self.TRANSCRIPT_ENDPOINT,
            json={"audio_url": audio_service_url}
        )
        start_transcription.raise_for_status()
        
        transcription_id = start_transcription.json()["id"]
        status_check_url = f"{self.TRANSCRIPT_ENDPOINT}/{transcription_id}"
        
        process_start = time.time()
        
        while time.time() - process_start < wait_limit:
            status_response = self.http_client.get(status_check_url)
            status_response.raise_for_status()
            
            current_status = status_response.json()["status"]
            
            if current_status == "completed":
                return status_response.json()["text"]
            elif current_status == "failed":
                return False
            
            #time.sleep(1)
        
        pass
    
    def remove_temp_files(self):
        if os.path.exists("captcha_audio.mp3"):
            os.remove("captcha_audio.mp3")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exception_type, exception_value, traceback):
        self.remove_temp_files()
