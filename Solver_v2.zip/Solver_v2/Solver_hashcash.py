import hashlib
import time
import random
import string

class HashcashEngine:
    def __init__(self):
        pass
    
    def make_suffix(self):
        chars = string.ascii_letters
        return ''.join(random.choice(chars) for _ in range(7))
    
    def work(self, prefix, zeros=5):
        start = time.time()
        tries = 0
        target = '0' * zeros
        
        while True:
            suffix = self.make_suffix()
            full_text = prefix + suffix
            h = hashlib.sha256(full_text.encode()).hexdigest()
            tries += 1
            
            if h.startswith(target):
                end = time.time()
                return {
                    'result': suffix,
                    'hash': h,
                    'tries': tries,
                    'time': end - start,
                    'prefix': prefix,
                    'full': full_text
                }
    
    def multi_work(self, prefix, count=10, zeros=5):
        results = []
        for i in range(count):
            res = self.work(prefix, zeros)
            results.append(res)
            
        return results
    
    def continuous_work(self, prefix, duration=30, zeros=5):
        end_time = time.time() + duration
        solutions = []
        target = '0' * zeros
        
        while time.time() < end_time:
            suffix = self.make_suffix()
            full_text = prefix + suffix
            h = hashlib.sha256(full_text.encode()).hexdigest()
            
            if h.startswith(target):
                solutions.append({
                    'suffix': suffix,
                    'hash': h,
                    'text': full_text
                })              
        
        return solutions


