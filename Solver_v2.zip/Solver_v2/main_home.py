import requests
import random
import uuid
import json
import time
import ast
import string
from Enc import edata
from Solver import CaptchaAudioDecoder
from Solver_hashcash import HashcashEngine
import queue
import ssl
import warnings
from Device import TikTokTokenGenerator 

engine = HashcashEngine()
student = TikTokTokenGenerator()
student.generate_tokens()

class main:
    def __init__(self):
        self.session = requests.Session()
        self.time = int(time.time())
        self.uuid = uuid.uuid4()
        with open("devices.txt", "r", encoding="utf-8") as f:
            self.setting = json.load(f)
        self.__device_id__ = self.setting['device_id']
        self.__iid__ = self.setting['iid']
        self.__device_type__ = self.setting['device_type']
        self.__device_brand__ = self.setting['device_brand']
        self.__cdid__ = self.setting['cdid']
        self.__verify_id__ = self.setting['verify_id']
        self.__msToken__ = self.setting['msToken']
        self.__fp__ = self.setting['fp']
        self.__detail__ = self.setting['detail']
        self.__region__ = self.setting['region']
        self.__browser_version__ = self.setting['browser_version']
        self.__X_Bogus__ = self.setting['X-Bogus']
        self.__signature__ = self.setting['_signature']
        self.__challenge_code__ = self.setting['challenge_code']
        self.running = True
        self.captcha_queue = queue.Queue()
        self.results_queue = queue.Queue()
        self.workers = []
        self.captcha_cache = {}
       
    
    def xor(self,text):
    	return "".join([hex(ord(_) ^ 5)[2:] for _ in text]) 
    
    def hash_cash(self, prefix):
        nn = ''.join(random.choices(string.ascii_letters + string.digits, k=7))
        return f"{prefix}{nn}"

    def captcha_worker(self, url):
        decoder = CaptchaAudioDecoder()
        np = decoder.decode_audio_captcha(url)
        cle = np.replace(" ", "").replace(".", "").replace(",", "")
        captcha_text = cle.lower()
        return captcha_text

    def get_captcha_fast(self):    	
        url = "https://verification-sg.tiktok.com/captcha/get"
        student.generate_tokens()
        current_time = int(time.time())
        params = {
            "lang": "en",
            "app_name": "adweb",
            "h5_sdk_version": "2.34.12",
            "h5_sdk_use_type": "goofy",
            "sdk_version": "",
            "iid": self.__iid__,
            "did": self.__device_id__,
            "device_id": self.__device_id__,
            "ch": "web_text",
            "aid": "1583",
            "os_type": "3",
            "mode": "voice",
            "tmp": current_time,
            "platform": "h5",
            "webdriver": "false",
            "enable_image": "1",
            "fp": self.__fp__,
            "type": "verify",
            "detail": self.__detail__,
            "server_sdk_env": '{"idc":"my","region":"%s","server_type":"passport"}' % self.__region__,
            "imagex_domain": "",
            "subtype": "voice",
            "challenge_code": self.__challenge_code__,
            "os_name": "iOS",
            "verify_id": self.__verify_id__,
            "h5_check_version": "3.8.20",
            "region": self.__region__,
            "triggered_region": self.__region__,
            "cookie_enabled": "true",
            "screen_width": "414",
            "screen_height": "896",
            "browser_language": "ar",
            "browser_platform": self.__device_brand__,
            "browser_name": "Mozilla",
            "browser_version": self.__browser_version__,
            "msToken": self.__msToken__,
            "X-Bogus": self.__X_Bogus__,
            "_signature": self.__signature__,
        }
        headers = {
            "content-type": "application/json; charset=utf-8",
            "user-agent": self.__browser_version__
        }
        try:
        	
            response = self.session.get(url, params=params, headers=headers, timeout=5).json()
            if 'edata' in response:
                decrypted = edata.decrypt(response['edata'])
                json_strings = decrypted.strip().split('\n')
                for json_str in json_strings:
                    try:
                        data = json.loads(json_str)
                        challenges = data['data']['challenges']
                        challenge1 = challenges[0]
                        challenge2 = challenges[1]
                        prefix = challenge2['question']['prefix']
                        answer = self.hash_cash(prefix)
                        return {
                            'verify_id': data['data']['verify_id'],
                            'challenge1_id': challenge1['id'],
                            'challenge1_url1': challenge1['question']['url1'],
                            'challenge2_id': challenge2['id'],
                            'answer': answer
                        }
                    except:
                        continue
        except:
            pass
        return None

    def single_verification(self):
        utlis = self.get_captcha_fast()
        if not utlis:
            return

        captcha_text = self.captcha_worker(utlis['challenge1_url1'])
        print(captcha_text)
        if not captcha_text:
            return

        current_time = int(time.time())
        print(utlis['answer'])
        url = 'https://verification-sg.tiktok.com/captcha/verify'
        headers = {
            "content-type": "application/json; charset=utf-8",
            "user-agent": self.__browser_version__
        }
        params = {
            "lang": "en",
            "app_name": "adweb",
            "h5_sdk_version": "2.34.12",
            "h5_sdk_use_type": "goofy",
            "sdk_version": "",
            "iid": self.__iid__,
            "did": self.__device_id__,
            "device_id": self.__device_id__,
            "ch": "web_text",
            "aid": "1583",
            "os_type": "3",
            "mode": "voice",
            "tmp": current_time,
            "platform": "h5",
            "webdriver": "false",
            "enable_image": "1",
            "fp": self.__fp__,
            "type": "verify",
            "detail": self.__detail__,
            "server_sdk_env": '{"idc":"my","region":"%s","server_type":"passport"}' % self.__region__,
            "imagex_domain": "",
            "subtype": "voice",
            "challenge_code": self.__challenge_code__,
            "os_name": "iOS",
            "verify_id": self.__verify_id__,
            "h5_check_version": "3.8.20",
            "region": self.__region__,
            "triggered_region": self.__region__,
            "cookie_enabled": "true",
            "screen_width": "414",
            "screen_height": "896",
            "browser_language": "ar",
            "browser_platform": self.__device_brand__,
            "browser_name": "Mozilla",
            "browser_version": self.__browser_version__,
            "msToken": self.__msToken__,
            "X-Bogus": self.__X_Bogus__,
            "_signature": self.__signature__,
        }
        request_data = {
            "id": utlis["challenge2_id"],
            "mode": "hashcash",
            "reply": [],
            "models": {},
            "reply2": [],
            "models2": {},
            "answer": utlis['answer'],
            "version": 2,
            "verify_id": utlis["verify_id"],
            "verify_requests": [
                {
                    "id": utlis["challenge1_id"],
                    "mode": "voice",
                    "reply": [{"answer": captcha_text}],
                    "models": {},
                    "reply2": [],
                    "models2": {},
                    "events": "{\"userMode\":0}"
                },
                {
                    "id": utlis["challenge2_id"],
                    "mode": "hashcash",
                    "reply": [],
                    "models": {},
                    "reply2": [],
                    "models2": {},
                    "answer": utlis['answer'],
                    "events": "{\"userMode\":0}"
                }
            ],
            "events": "{\"userMode\":0}"
        }
        json_data = json.dumps(request_data)
        encrypted_json = edata.encrypt(json_data)
        payload = {"edata": encrypted_json}
        try:
            response = self.session.post(url, headers=headers, params=params, json=payload, timeout=10).json()
            if 'edata' in response:
                result = edata.decrypt(response['edata'])
                if '200' in result:
                	print('✅ True Solver')    
                	with open('devices_Solver', 'w') as f:
                		f.write(str(self.setting)) 
                	                 
                else:
                	print('❌ Bad Solver')                  
        except:
            pass
            
            
nn = main()
while True:
	nn.single_verification()
