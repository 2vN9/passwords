import requests
import json
import time
import random
import string
import uuid


class TikTokTokenGenerator:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'X-Requested-With': 'XMLHttpRequest'
        })
        self.time = int(time.time())
        
    def generate_tokens(self):
        device_id = self.verify_device_id()
        if not device_id:
            return None
            
        iid = device_id
        cdid, device_type, device_brand = self.generate_device_info()
        fp, detail, region, log_id = self.get_fingerprint_data()
        ms_token = self.get_ms_token()
        
        chars = string.ascii_letters + string.digits
        bogus = 'DFSzsIVL770' + ''.join(random.choices(chars, k=15))
        
        chars = string.digits + string.ascii_letters
        signature = '_02B4Z6' + ''.join(random.choices(chars, k=6)) + '000001WTSFuwAAIDBZNIW7pO' + ''.join(random.choices(chars, k=4)) + '0BJAADB-18'
        
        verify_id = 'Verify_' + str(uuid.uuid4())
        user_agent = self.generate_user_agent()
        
        tokens_data = {
            'device_id': device_id,
            'iid': iid,
            'device_type': device_type,
            'device_brand': device_brand,
            'cdid': cdid,
            'msToken': ms_token,
            'fp': fp,
            'detail': detail,
            'region': region,
            'log_id': log_id,
            'challenge_code': 99994,
            'browser_version': user_agent,
            'X-Bogus': bogus,
            '_signature': signature,
            'verify_id': verify_id
        }
        
        
        with open('devices.txt', 'w') as f:
            json.dump(tokens_data, f) 
        
        return tokens_data
    
    def verify_device_id(self):
        url = 'https://mcs-sg.tiktok.com/v1/user/webid'
        
        headers = {
            'authority': 'business-sso.tiktok.com',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://getstarted.tiktok.com',
            'referer': 'https://getstarted.tiktok.com/brandnew-meta?lang=en&attr_source=google&attr_medium=search-br-ad&attr_adgroup_id=183801375117&attr_term=tiktok%20business&gad_source=1&gad_campaignid=22884088272&gbraid=0AAAAACeGRgQwck1aoukbeQIiLSt2PM3Pl&gclid=EAIaIQobChMIiMiC1_zikQMVmsl5BB2I_R4XEAAYASAAEgJfzfD_BwE',
            'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': self.generate_user_agent(),
            'x-requested-with': 'XMLHttpRequest',
            'x-tt-passport-csrf-token': str(self.time)
        }
        
        data = {
            "app_id": 2741,
            "referer": "https://ads.tiktok.com/creative/signup",
            "url": "https://ads.tiktok.com/i18n/login?redirect=https%3A%2F%2Fads.tiktok.com%2Fcreative%2Fsignup&_source_=tiktok-one",
            "user_agent": self.generate_user_agent(),
            "user_unique_id": ""
        }
        
        try:
            response = self.session.post(url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            data = response.json()
            return data.get('web_id')
        except Exception as e:
            return None
    
    def generate_device_info(self):
        cdid = str(uuid.uuid4())
        device_type = random.choice(["SM-S908E", "SM-G991B", "Pixel 6 Pro", "Mi 11 Ultra"])
        device_brand = random.choice(["samsung", "google", "xiaomi", "huawei"])
        return cdid, device_type, device_brand
    
    def generate_user_agent(self):
        app_versions = ['2023708050', '2023708051', '2023708052', '2023708053', '2023708054']
        android_versions = ['9', '10', '11', '12', '13']
        locales = ['en_GB', 'en_US', 'ar_SA', 'fr_FR', 'de_DE']
        devices = ['SM-S908E', 'SM-G998B', 'SM-N986B', 'SM-F936B', 'SM-A736B']
        builds = ['TP1A.220624.014', 'SP1A.210812.016', 'RP1A.200720.012', 'QP1A.190711.020', 'PPR1.180610.011']
        tt_ok_versions = ['3.12.13.16', '3.12.13.15', '3.12.13.14', '3.12.13.13']
        
        return f"com.zhiliaoapp.musically/{random.choice(app_versions)} (Linux; U; Android {random.choice(android_versions)}; {random.choice(locales)}; {random.choice(devices)}; Build/{random.choice(builds)};tt-ok/{random.choice(tt_ok_versions)})"
    
    def get_ms_token(self):
        url = "https://mssdk-sg.tiktok.com/web/report"
        params = {
            'msToken': 'FbNfo2aMkzatMW_p9mNd64AbTE1vSqTBHatXQnFnbt9WKB2zchyvYJWPy4PqxDPAfYXTrAKCgPWYknXEhxs8O4MPFc9Wqe7_15I0ffSRrCPm3Z_t6VdMa8Mp5B41uzU3OLMz',
            'X-Bogus': 'DFSzswVufr4EODwyCmRownYO8-eF',
            'X-Gnarly': 'MxfEZ-rRi9KeNv8BDqH/PQJBRQHA3lhLZIp4lxaz5tDzACH4aArlVYtTzmdJ53Q3g1-mpkosMqCFsSDYLrSJiOCBvmxVDyrOG1-fJVe5xT3MJl3RAEi10oWiUvP4LNbPvg/IeWvdtoknIxdww/aakXByZPEvILEarPaqktivOMqxdw8kxUHCPp/9llm1bk7IKyXgx3Vs6m9nn45aBBBdO7k3JZvqkzbjfcz/3gJugCTlcl731d9IMw4xpyQOSSgZ7Ed1eAeObPsNQFfr0j2Aw1ulgw3WmwiNqE79zRXgIdlh28NTkb7ZvJmXNnFij5rOq9W='
        }
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            cookies = self.session.cookies.get_dict()
            return cookies.get('msToken', '')
        except Exception as e:
            return None
    
    def get_fingerprint_data(self):
        headers = {
            'authority': 'business-sso.tiktok.com',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://getstarted.tiktok.com',
            'referer': 'https://getstarted.tiktok.com/brandnew-meta?lang=en&attr_source=google&attr_medium=search-br-ad&attr_adgroup_id=183801375117&attr_term=tiktok%20business&gad_source=1&gad_campaignid=22884088272&gbraid=0AAAAACeGRgQwck1aoukbeQIiLSt2PM3Pl&gclid=EAIaIQobChMIiMiC1_zikQMVmsl5BB2I_R4XEAAYASAAEgJfzfD_BwE',
            'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
            'x-tt-passport-csrf-token': str(self.time)
        }
        
        data = {
            'mix_mode': '1',
            'aid': '1583',
            'service': 'https://getstarted.tiktok.com/brandnew-meta?lang=en&attr_source=google&attr_medium=search-br-ad&attr_adgroup_id=183801375117&attr_term=tiktok%20business&gad_source=1&gad_campaignid=22884088272&gbraid=0AAAAACeGRgQwck1aoukbeQIiLSt2PM3Pl&gclid=EAIaIQobChMIiMiC1_zikQMVmsl5BB2I_R4XEAAYASAAEgJfzfD_BwE',
            'language': 'en',
            'email': '0',
            'password': '0',
            'fp': '0',
            'verifyFp': '0',
            'ect_type': '1',
            'email_logic_type': '1'
        }
        
        try:
            url = 'https://business-sso.tiktok.com/send_email_activate_code/v2/'
            params = {
                'msToken': 'h',
                'X-Bogus': 'h',
                '_signature': 'h'
            }
            
            response = self.session.post(url, headers=headers, data=data, params=params, timeout=30)
            response.raise_for_status()
            
            if 'verify_center_decision_conf' in response.text:
                res = response.json()
                if 'verify_center_decision_conf' in res:
                    inner = json.loads(res['verify_center_decision_conf'])
                    return (
                        inner.get('fp', ''),
                        inner.get('detail', ''),
                        inner.get('region', ''),
                        inner.get('log_id', '')
                    )
            return '', '', '', ''
        except Exception as e:
            return '', '', '', ''


